//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MilkshapeExport.rc
//
#define IDD_OPTIONS                     101
#define IDC_EXPORT_MATERIALS            1001
#define IDC_EXPORT_MESH                 1003
#define IDC_CHECK2                      1004
#define IDC_EXPORT_SKEL                 1004
#define IDC_SPLIT_ANIMATION             1005
#define IDC_EDIT1                       1006
#define IDC_FPS                         1006
#define IDC_GRP_MESH                    1007
#define IDC_GENERATE_LOD                1008
#define IDC_LOD_DEPTH                   1009
#define IDC_LOD_VRQ                     1010
#define IDC_CBO_LOD_STYLE               1011
#define IDC_GRP_SKELETON                1012
#define IDC_GRP_MATERIAL                1013
#define IDC_NUM_LODS                    1014
#define IDC_EDGE_LISTS                  1016
#define IDC_TANGENT_VECTORS             1017
#define IDC_TANG_SPLIT_MIRR             1018
#define IDC_TANGENTS_TARGET             1019
#define IDC_TANG_SPLIT_ROT              1020
#define IDC_4D_TANGENTS                 1021



// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
