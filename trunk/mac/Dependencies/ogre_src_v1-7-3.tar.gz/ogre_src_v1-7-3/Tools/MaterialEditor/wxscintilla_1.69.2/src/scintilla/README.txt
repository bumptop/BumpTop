This directory contains copies of the scintilla/src and
scintilla/include directories from the Scintilla source
distribution.

The current version of the Scintilla code is 1.62
