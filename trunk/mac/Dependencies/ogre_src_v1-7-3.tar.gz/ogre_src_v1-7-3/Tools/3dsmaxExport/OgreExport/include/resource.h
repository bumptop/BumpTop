//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by OgreMaxExporter.rc
//
#define IDC_CMD_HELP                    3
#define IDD_EXPORT                      101
#define IDI_ICON1                       103
#define IDB_BITMAP1                     104
#define IDS_BINARY                      105
#define IDD_BINARY_EXPORT               106
#define IDD_TAB_GENERAL                 109
#define IDD_TAB_MESH                    110
#define IDD_TAB_SKELETAL_ANIMATION      112
#define IDD_TAB_VERTEX_ANIMATION        113
#define IDD_TAB_MATERIAL                114
#define IDC_EXPORT                      1005
#define IDC_RADIO_EXPORT_FILES          1006
#define IDC_RADIO_EXPORT_SUBMESHES      1007
#define IDC_TXT_EXPORT_DIR              1009
#define IDC_SELECT_EXPORT_DIR           1010
#define IDC_CHK_SHARE_SKELETON          1011
#define IDC_CHK_REBUILD_NORMALS         1012
#define IDC_CHK_MERGE_MESHES            1013
#define IDC_RADIO_UV                    1014
#define IDC_RADIO_VW                    1015
#define IDC_RADIO_WU                    1016
#define IDC_TXT_MATERIAL_FILENAME       1017
#define IDC_CHK_FLIP_YZ                 1018
#define IDC_CHK_VERTEX_COLORS           1019
#define IDC_TXT_SCALE                   1020
#define IDC_CHK_INVERT_NORMALS          1021
#define IDC_TXT_SKELETON_FILENAME       1022
#define IDC_CHK_VERTEX_COLORS2          1022
#define IDC_TXT_DEFAULT_MATERIAL        1023
#define IDC_RADIO_EXPORT_MATERIALS      1024
#define IDC_CHK_GENERATE_TANGENTS       1024
#define IDC_CHK_GENERATE_EDGELISTS      1025
#define IDC_CHK_GENERATE_LOD            1026
#define IDC_CHK_OPTIMIZE                1027
#define IDC_RADIO_UV2                   1028
#define IDC_CHK_GENERATE_TANGENTS2      1029
#define IDC_LIST_ANIMATIONS             1030
#define IDC_TXT_FPS                     1031
#define IDC_TXT_ANIMATION_NAME          1032
#define IDC_TXT_ANIM_START              1033
#define IDC_TXT_ANIM_END                1034
#define IDC_CMD_ADD_ANIMATION           1035
#define IDC_CMD_DELETE_ANIMATION        1036
#define IDC_TXT_FRAME_RANGE             1037
#define IDC_LOD_NUM_LEVELS              1038
#define IDC_LOD_USE_PERCENT             1039
#define IDC_LOD_DISTANCE                1040
#define IDC_LOD_PERCENT                 1041
#define IDC_LOD_USE_VERTEX              1042
#define IDC_LOD_VERTEX_COUNT            1043
#define IDC_COLOR_FORMAT                1044
#define IDC_ENDIAN                      1045
#define IDC_STATIC_TITLE                1046
#define IDC_RADIO_VW2                   1046
#define IDC_STATIC_COPYRIGHT            1047
#define IDC_RADIO_WU2                   1047
#define IDC_STATIC_VERSION              1048
#define IDC_TXT_MATERIAL_FILENAME2      1048
#define IDC_TABCONTROL                  1049
#define IDC_TXT_DEFAULT_MATERIAL2       1049
#define IDC_CHK_BINARY_MESH             1052

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        115
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1053
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
