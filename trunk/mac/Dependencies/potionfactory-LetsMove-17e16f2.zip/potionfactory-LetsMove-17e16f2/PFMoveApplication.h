//
//  PFMoveApplication.h, version 1.3
//  LetsMove
//
//  Created by Andy Kim at Potion Factory LLC on 9/17/09
//
//  The contents of this file are dedicated to the public domain.

#import <Foundation/Foundation.h>

void PFMoveToApplicationsFolderIfNecessary();
